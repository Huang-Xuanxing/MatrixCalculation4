## NOTE:
1.need to send POST request to the client server to upload the file.The request that need to send is "http://{IP_ADDRES}:8082/uploadFile"

2.Change the application.proporties can change the port of grpc server.

3.The sample matrix file is named as Matrix.txt. It contains two 4*4 matrics. The first fourth row is for the first matrix, the rest of the row is for the second matrix.

