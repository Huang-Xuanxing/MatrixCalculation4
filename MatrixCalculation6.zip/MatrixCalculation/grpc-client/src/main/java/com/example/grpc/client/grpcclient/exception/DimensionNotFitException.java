package com.example.grpc.client.grpcclient.exception;

public class DimensionNotFitException extends Exception{
}
